<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Product</title>
</head>

<body>
    <div class="container-body">
        <div class="container-content">
            <label for="product-name">Name:</label>
            <input type="text" name="product-name" id="product-name">
        </div>
        <div class="container-content">
            <label for="product-description">Description:</label>
            <input type="text" name="product-description" id="product-description">
        </div>
        <div class="container-content">
            <label for="product-code">Code:</label>
            <input type="text" name="product-code" id="product-code">
        </div>
        <div class="container-content">
            <label for="product-price">Price:</label>
            <input type="text" name="product-price" id="product-price">
        </div>
        <div class="container-content">
            <label for="product-quantity">Quantity:</label>
            <input type="text" name="product-price" id="product-price">
        </div>
    </div>

</body>

</html>