# inventory_system

I disabled the session and cookie functions due to error upon deploying online hence it is working offline.

to check the website, here is the link:
https://blackcrips-inventory.000webhostapp.com
