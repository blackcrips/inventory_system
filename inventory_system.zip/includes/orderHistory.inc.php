<?php
include_once('./autoLoadClasses.inc.php');
$loginController = new productsView();
$loginController->viewOrderHistory();
