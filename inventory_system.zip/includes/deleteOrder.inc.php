<?php
include_once('./autoLoadClasses.inc.php');

$loginController = new LoginController();
$loginController->deleteOrder();