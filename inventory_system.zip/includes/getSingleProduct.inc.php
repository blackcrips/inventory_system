<?php
include_once('./autoLoadClasses.inc.php');
$productsView = new ProductsView();
$productsView->getSingleProductToEdit();